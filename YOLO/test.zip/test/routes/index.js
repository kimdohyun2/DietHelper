var express = require('express');
var router = express.Router();
//var multiparty = require('multiparty');
//var cheerio = require('cheerio');
const download = require('image-downloader')


var client_id = 'CE1GRvTQCs3PXN5kOe9G';
var client_secret = 'LZQ1cYRoD_';


router.get('/', function (req, res, next) {
  
  var api_url = "https://openapi.naver.com/v1/search/image?query=%EA%B3%BC%EC%9D%BC%20%EB%B0%A9%EC%9A%B8%ED%86%A0%EB%A7%88%ED%86%A0&display=100&start=1&sort=sim"; // json 결과
  var request = require('request');
  var options = {
    url: api_url,
    headers: { 'X-Naver-Client-Id': client_id, 'X-Naver-Client-Secret': client_secret }
  };
  request.get(options, function (error, response, body) {
    if (!error && response.statusCode == 200) {
      res.writeHead(200, { 'Content-Type': 'text/json;charset=utf-8' });
      var a = JSON.parse(body);
      
        for(var i = 0 ; i < 100; i++){
          var xx = {
            url:a.items[i].link,
            dest:'D:/images/tomato',             // Save to /path/to/dest/image.jpgd 
          }
          
          download.image(xx)
            .then(({ filename, image }) => {
              console.log('File saved to', filename)
              //console.log("i"+i+"link"+a.items[i].link)
            })
            .catch((err) => {
              console.error(err)
            })
            
      }
      
      // Download to a directory and save with the original filename
      res.end(body);
    } else {
      res.status(response.statusCode).end();
      console.log('error = ' + response.statusCode);
    }
  });

  /* router.post('/upload', function (req, res) {
     var form = new multiparty.Form({
       autoFiles: true, // 요청이 들어오면 파일을 자동으로 저장할 것인가
       uploadDir: 'public/images/', // 파일이 저장되는 경로(프로젝트 내의 temp 폴더에 저장됩니다.)
       maxFilesSize: 1024 * 1024 * 5 // 허용 파일 사이즈 최대치
     });
   
     form.parse(req, function (error, fields, files) {
       // 파일 전송이 요청되면 이곳으로 온다.
       // 에러와 필드 정보, 파일 객체가 넘어온다.
       var path = files.fileInput[0].path.replace(/public/gi, "");
       var titles = fields.titles[0];
       var breed = fields.breed[0];
       var age = fields.age[0];
       var sex = fields.sex[0];
       var comment = fields.comment[0];
       var sessionID = req.session.userInfo.user_id;
       mydb.aniPostInsert(sessionID, titles, path, breed, sex, age, comment, function (insertRes) {
         if (insertRes) {
           res.redirect('/preSecondPage');
         }
       });
     });
   
   });
 
 */
/*f(j < 3){
  res.redirect("/");
}*/
});
module.exports = router;
